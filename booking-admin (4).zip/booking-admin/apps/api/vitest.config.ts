import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { include: ['tests/**/*.test.ts'], setupFiles: ['tests/setup.ts'], fileParallelism: false, testTimeout: 40000, hookTimeout: 60000, pool: 'forks' } });
